from django import forms

from .models import Comment


class AddCommentForm(forms.Modelforms):
    class Meta:
        model = Comment
        fields = ('content',)
